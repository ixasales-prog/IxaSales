-- Add xlsx to export_format enum
ALTER TYPE export_format ADD VALUE IF NOT EXISTS 'xlsx';

-- Add schedule_time column to tenant_export_settings
ALTER TABLE tenant_export_settings ADD COLUMN IF NOT EXISTS schedule_time VARCHAR(5) DEFAULT '03:00';

-- Add send_to_telegram column to tenant_export_settings
ALTER TABLE tenant_export_settings ADD COLUMN IF NOT EXISTS send_to_telegram BOOLEAN DEFAULT FALSE;
