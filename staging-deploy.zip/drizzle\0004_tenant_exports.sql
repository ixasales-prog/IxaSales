-- 0004_tenant_exports.sql
-- Tenant backup/export system for tenant admins

-- Create enums for export system
DO $$ BEGIN
    CREATE TYPE export_status AS ENUM ('pending', 'processing', 'completed', 'failed');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE export_format AS ENUM ('json', 'csv');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE export_frequency AS ENUM ('never', 'daily', 'weekly', 'monthly');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create tenant_exports table (individual export jobs)
CREATE TABLE IF NOT EXISTS tenant_exports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    
    -- Export configuration
    format export_format DEFAULT 'json',
    status export_status DEFAULT 'pending',
    
    -- What data to include
    include_products BOOLEAN DEFAULT true,
    include_customers BOOLEAN DEFAULT true,
    include_orders BOOLEAN DEFAULT true,
    include_payments BOOLEAN DEFAULT true,
    include_inventory BOOLEAN DEFAULT true,
    
    -- Date range filter (optional)
    date_from TIMESTAMP,
    date_to TIMESTAMP,
    
    -- Result
    filename VARCHAR(255),
    file_size INTEGER,
    error_message TEXT,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP,
    expires_at TIMESTAMP,
    downloaded_at TIMESTAMP,
    
    -- Who created it
    created_by_id UUID
);

-- Create tenant_export_settings table (scheduled export configuration)
CREATE TABLE IF NOT EXISTS tenant_export_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL UNIQUE REFERENCES tenants(id) ON DELETE CASCADE,
    
    -- Schedule
    frequency export_frequency DEFAULT 'never',
    format export_format DEFAULT 'json',
    
    -- What to include in scheduled exports
    include_products BOOLEAN DEFAULT true,
    include_customers BOOLEAN DEFAULT true,
    include_orders BOOLEAN DEFAULT true,
    include_payments BOOLEAN DEFAULT true,
    include_inventory BOOLEAN DEFAULT true,
    
    -- Retention
    retention_days INTEGER DEFAULT 30,
    
    -- Last run
    last_export_at TIMESTAMP,
    next_export_at TIMESTAMP,
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes for efficient queries
CREATE INDEX IF NOT EXISTS idx_tenant_exports_tenant_id ON tenant_exports(tenant_id);
CREATE INDEX IF NOT EXISTS idx_tenant_exports_status ON tenant_exports(status);
CREATE INDEX IF NOT EXISTS idx_tenant_exports_created_at ON tenant_exports(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tenant_export_settings_tenant_id ON tenant_export_settings(tenant_id);
CREATE INDEX IF NOT EXISTS idx_tenant_export_settings_next_export ON tenant_export_settings(next_export_at) 
    WHERE frequency != 'never' AND next_export_at IS NOT NULL;
