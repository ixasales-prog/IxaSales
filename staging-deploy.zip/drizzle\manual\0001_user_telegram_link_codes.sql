-- User Telegram Link Codes
-- These codes allow users (admins, sales reps, etc.) to link their Telegram accounts

CREATE TABLE IF NOT EXISTS user_telegram_link_codes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    code VARCHAR(20) NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT unique_link_code UNIQUE(tenant_id, code),
    CONSTRAINT unique_user_pending_link UNIQUE(user_id)
);

-- Index for faster code lookups
CREATE INDEX IF NOT EXISTS idx_user_telegram_link_codes_tenant_code ON user_telegram_link_codes(tenant_id, code);
CREATE INDEX IF NOT EXISTS idx_user_telegram_link_codes_expires_at ON user_telegram_link_codes(expires_at);
