CREATE TABLE IF NOT EXISTS "tenant_notification_settings" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"notify_new_order" boolean DEFAULT true,
	"notify_payment_received" boolean DEFAULT true,
	"notify_delivery_completed" boolean DEFAULT true,
	"notify_return_processed" boolean DEFAULT true,
	"notify_low_stock" boolean DEFAULT true,
	"notify_due_debt" boolean DEFAULT false,
	"low_stock_threshold" integer DEFAULT 10,
	"due_debt_days_threshold" integer DEFAULT 7,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	CONSTRAINT "tenant_notification_settings_tenant_id_unique" UNIQUE("tenant_id")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "master_products" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"sku" varchar(100) NOT NULL,
	"barcode" varchar(100),
	"name" varchar(255) NOT NULL,
	"description" text,
	"category" varchar(100),
	"image_url" varchar(500),
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	CONSTRAINT "master_products_sku_unique" UNIQUE("sku")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "system_settings" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"key" varchar(100) NOT NULL,
	"value" text,
	"description" varchar(500),
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	CONSTRAINT "system_settings_key_unique" UNIQUE("key")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "product_images" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"product_id" uuid NOT NULL,
	"url" varchar(500) NOT NULL,
	"thumbnail_url" varchar(500),
	"medium_url" varchar(500),
	"alt_text" varchar(255),
	"sort_order" integer DEFAULT 0,
	"is_primary" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "tenants" ALTER COLUMN "currency" SET DEFAULT 'UZS';--> statement-breakpoint
ALTER TABLE "tenants" ALTER COLUMN "timezone" SET DEFAULT 'Asia/Tashkent';--> statement-breakpoint
ALTER TABLE "tenants" ADD COLUMN "order_number_prefix" varchar(20) DEFAULT 'ORD-';--> statement-breakpoint
ALTER TABLE "tenants" ADD COLUMN "invoice_number_prefix" varchar(20) DEFAULT 'INV-';--> statement-breakpoint
ALTER TABLE "tenants" ADD COLUMN "default_payment_terms" integer DEFAULT 7;--> statement-breakpoint
ALTER TABLE "tenants" ADD COLUMN "address" varchar(500);--> statement-breakpoint
ALTER TABLE "tenants" ADD COLUMN "city" varchar(100);--> statement-breakpoint
ALTER TABLE "tenants" ADD COLUMN "country" varchar(100);--> statement-breakpoint
ALTER TABLE "tenants" ADD COLUMN "phone" varchar(50);--> statement-breakpoint
ALTER TABLE "tenants" ADD COLUMN "email" varchar(255);--> statement-breakpoint
ALTER TABLE "tenants" ADD COLUMN "website" varchar(255);--> statement-breakpoint
ALTER TABLE "tenants" ADD COLUMN "tax_id" varchar(100);--> statement-breakpoint
ALTER TABLE "tenants" ADD COLUMN "logo" varchar(500);--> statement-breakpoint
ALTER TABLE "tenants" ADD COLUMN "telegram_enabled" boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE "tenants" ADD COLUMN "telegram_bot_token" varchar(100);--> statement-breakpoint
ALTER TABLE "customers" ADD COLUMN "telegram_chat_id" varchar(50);--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "tenant_notification_settings" ADD CONSTRAINT "tenant_notification_settings_tenant_id_tenants_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "product_images" ADD CONSTRAINT "product_images_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
