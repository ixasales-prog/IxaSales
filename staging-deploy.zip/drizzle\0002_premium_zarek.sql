DO $$ BEGIN ALTER TYPE "public"."order_status" ADD VALUE 'confirmed' BEFORE 'approved'; EXCEPTION WHEN duplicate_object THEN null; END $$;--> statement-breakpoint
DO $$ BEGIN ALTER TYPE "public"."order_status" ADD VALUE 'returned' BEFORE 'partial'; EXCEPTION WHEN duplicate_object THEN null; END $$;--> statement-breakpoint
ALTER TABLE "notification_logs" ALTER COLUMN "event_type" SET NOT NULL;--> statement-breakpoint
DO $$ BEGIN ALTER TABLE "notification_logs" ADD COLUMN "recipient_type" varchar(20) DEFAULT 'admin'; EXCEPTION WHEN duplicate_column THEN null; END $$;--> statement-breakpoint
DO $$ BEGIN ALTER TABLE "notification_logs" ADD COLUMN "recipient_id" uuid; EXCEPTION WHEN duplicate_column THEN null; END $$;--> statement-breakpoint
DO $$ BEGIN ALTER TABLE "notification_logs" ADD COLUMN "recipient_chat_id" varchar(50); EXCEPTION WHEN duplicate_column THEN null; END $$;--> statement-breakpoint
DO $$ BEGIN ALTER TABLE "notification_logs" ADD COLUMN "reference_type" varchar(50); EXCEPTION WHEN duplicate_column THEN null; END $$;--> statement-breakpoint
DO $$ BEGIN ALTER TABLE "notification_logs" ADD COLUMN "reference_id" uuid; EXCEPTION WHEN duplicate_column THEN null; END $$;--> statement-breakpoint
DO $$ BEGIN ALTER TABLE "notification_logs" ADD COLUMN "retry_count" integer DEFAULT 0; EXCEPTION WHEN duplicate_column THEN null; END $$;--> statement-breakpoint
DO $$ BEGIN ALTER TABLE "notification_logs" ADD COLUMN "metadata" jsonb; EXCEPTION WHEN duplicate_column THEN null; END $$;