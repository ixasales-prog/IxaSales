ALTER TYPE "public"."order_status" ADD VALUE 'confirmed' BEFORE 'approved';--> statement-breakpoint
ALTER TYPE "public"."order_status" ADD VALUE 'returned' BEFORE 'partial';--> statement-breakpoint
ALTER TABLE "notification_logs" ALTER COLUMN "event_type" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "notification_logs" ADD COLUMN "recipient_type" varchar(20) DEFAULT 'admin';--> statement-breakpoint
ALTER TABLE "notification_logs" ADD COLUMN "recipient_id" uuid;--> statement-breakpoint
ALTER TABLE "notification_logs" ADD COLUMN "recipient_chat_id" varchar(50);--> statement-breakpoint
ALTER TABLE "notification_logs" ADD COLUMN "reference_type" varchar(50);--> statement-breakpoint
ALTER TABLE "notification_logs" ADD COLUMN "reference_id" uuid;--> statement-breakpoint
ALTER TABLE "notification_logs" ADD COLUMN "retry_count" integer DEFAULT 0;--> statement-breakpoint
ALTER TABLE "notification_logs" ADD COLUMN "metadata" jsonb;